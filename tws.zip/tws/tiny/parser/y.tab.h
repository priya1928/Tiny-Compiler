/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    NEQ = 258,
    END = 259,
    TO = 260,
    VAR = 261,
    IDENTIFIER = 262,
    CHR = 263,
    POOL = 264,
    IF = 265,
    FUNCTION = 266,
    READ = 267,
    REPEAT = 268,
    CHAR_VAL = 269,
    RETURN = 270,
    ELSE = 271,
    UNTIL = 272,
    SWAP = 273,
    FOR = 274,
    THEN = 275,
    DOTDOT = 276,
    OF = 277,
    MOD = 278,
    CASE = 279,
    WHILE = 280,
    OUTPUT = 281,
    EXIT = 282,
    PROCEDURE = 283,
    CONST = 284,
    Eof = 285,
    GTE = 286,
    PRED = 287,
    NOT = 288,
    DO = 289,
    BEGINX = 290,
    INTEGER_NUM = 291,
    ORD = 292,
    AND = 293,
    STR_VAL = 294,
    EXP = 295,
    LTE = 296,
    LOOP = 297,
    SUCC = 298,
    TYPE = 299,
    OR = 300,
    OTHERWISE = 301,
    ASSIGNMENT = 302,
    PROGRAM = 303,
    DOWNTO = 304
  };
#endif
/* Tokens.  */
#define NEQ 258
#define END 259
#define TO 260
#define VAR 261
#define IDENTIFIER 262
#define CHR 263
#define POOL 264
#define IF 265
#define FUNCTION 266
#define READ 267
#define REPEAT 268
#define CHAR_VAL 269
#define RETURN 270
#define ELSE 271
#define UNTIL 272
#define SWAP 273
#define FOR 274
#define THEN 275
#define DOTDOT 276
#define OF 277
#define MOD 278
#define CASE 279
#define WHILE 280
#define OUTPUT 281
#define EXIT 282
#define PROCEDURE 283
#define CONST 284
#define Eof 285
#define GTE 286
#define PRED 287
#define NOT 288
#define DO 289
#define BEGINX 290
#define INTEGER_NUM 291
#define ORD 292
#define AND 293
#define STR_VAL 294
#define EXP 295
#define LTE 296
#define LOOP 297
#define SUCC 298
#define TYPE 299
#define OR 300
#define OTHERWISE 301
#define ASSIGNMENT 302
#define PROGRAM 303
#define DOWNTO 304

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE YYSTYPE;
union YYSTYPE
{
#line 16 "code.y" /* yacc.c:1909  */

   TOKEN_INFO info;
   DLIST dlist;

#line 157 "y.tab.h" /* yacc.c:1909  */
};
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
