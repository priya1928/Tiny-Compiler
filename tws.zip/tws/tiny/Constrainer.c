/****************************************************************
              Copyright (C) 1986 by Manuel E. Bermudez
              Translated to C - 1991
*****************************************************************/
#include <string.h>
#include <stdio.h>
#include <header/Open_File.h>
#include <header/CommandLine.h>
#include <header/Table.h>
#include <header/Text.h>
#include <header/Error.h>
#include <header/String_Input.h> 
#include <header/Tree.h>
#include <header/Dcln.h>
#include <header/Constrainer.h>

#define ProgramNode    1
#define TypesNode      2
#define TypeNode       3
#define DclnsNode      4
#define VarNode        5
#define IntegerTNode   6
#define BooleanTNode   7
#define BlockNode      8
#define AssignNode     9
#define OutputNode     10
#define IfNode         11
#define WhileNode      12
#define NullNode       13
#define NotNode	       14
#define LENode         15
#define GTENode        16
#define NEQNode        17
#define LTNode         18
#define GTNode         19
#define EQNode         20
#define ExpNode        21
#define PlusNode       22
#define MinusNode      23
#define MultNode       24
#define DivNode        25
#define AndNode        26
#define ModNode	       27
#define OrNode	       28
#define TrueNode       29
#define FalseNode      30
#define ReadNode       31
#define IntegerNode    32
#define IdentifierNode 33
#define EofNode        34
#define RepeatNode     35
#define LoopNode       36
#define ToNode         37
#define ExitNode       38
#define LOOP_CTXT      39
#define FOR_CTXT       40
#define SwapNode       41
#define CaseNode       42
#define CaseClauseNode 43
#define DotDotNode     44
#define OtherwiseNode  45
#define DownToNode     46
#define ConstsNode     47
#define ConstNode      48
#define LitNode        49
#define CharacterTNode 50
#define CharacterNode  51
#define SuccNode       52
#define PredNode       53
#define ChrNode        54
#define OrdNode        55
#define ExpType	       56
#define LineNode       57
#define SubProgsNode   58
#define SUBPROG_CTXT   59
#define FunctionNode   60
#define ReturnNode     61
#define ParamsNode     62
#define CallNode       63
#define ProcedureNode  64

#define NumberOfNodes  64

typedef TreeNode UserType;

/****************************************************************
 Add new node names to the end of the array, keeping in strict
  order with the define statements above, then adjust the i loop
  control variable in InitializeConstrainer().
*****************************************************************/
char *node[] = { "program", "types", "type", "dclns",
                 "var", "integer", "boolean", "block",
                 "assign", "output", "if", "while", 
                 "<null>","not", "<=",">=","<>","<",">","=","**", "+", "-","*","/","and","mod","or","true","false", "read",
                 "<integer>", "<identifier>","eof","repeat","loop","to","exit", 
                 "<loop_ctxt>" ,"<for_ctxt>",":=:","case","<case_clause>","..","otherwise","downto","consts","const","lit","char","<char>","succ",
		 "pred","chr","ord","exptype","<string>","subprogs","<subprog_ctxt>","function","return","params","call","procedure"};


UserType TypeInteger, TypeBoolean, TypeChar;
boolean TraceSpecified;
FILE *TraceFile;
char *TraceFileName;
int NumberTreesRead, index;


void Constrain(void)    
{
   int i;
   InitializeDeclarationTable();
   Tree_File = Open_File("_TREE", "r"); 
   NumberTreesRead = Read_Trees();
   fclose (Tree_File);                     

   AddIntrinsics();

#if 0
   printf("CURRENT TREE\n");
   for (i=1;i<=SizeOf(Tree);i++)
      printf("%2d: %d\n",i,Element(Tree,i));
#endif

   ProcessNode(RootOfTree(1)); 

    
   Tree_File = fopen("_TREE", "w");  
   Write_Trees();
   fclose (Tree_File);                   

   if (TraceSpecified)
      fclose(TraceFile);    
}


void InitializeConstrainer (int argc, char *argv[])
{          
   int i, j;

   InitializeTextModule();
   InitializeTreeModule();

   for (i=0, j=1; i<NumberOfNodes; i++, j++)
      String_Array_To_String_Constant (node[i], j); 
 
   index = System_Flag ("-trace", argc, argv);
 
   if (index)                                       
   {
      TraceSpecified = true; 
      TraceFileName = System_Argument ("-trace", "_TRACE", argc, argv);
      TraceFile = Open_File(TraceFileName, "w");
   }
   else
      TraceSpecified = false;          
}                        


void AddIntrinsics (void)
{
   TreeNode TempTree;

   AddTree (TypesNode, RootOfTree(1), 2);

   TempTree = Child (RootOfTree(1), 2);
   AddTree (TypeNode, TempTree, 1);

   TempTree = Child (RootOfTree(1), 2);
   AddTree (TypeNode, TempTree, 2);

   TempTree = Child (RootOfTree(1), 2);
   AddTree (TypeNode, TempTree, 3);

   TempTree = Child (Child (RootOfTree(1), 2), 1);
   AddTree (IdentifierNode, TempTree, 1);

   TempTree = Child(Child (Child (RootOfTree(1), 2), 1),1);
   AddTree (BooleanTNode, TempTree, 1); 

   TempTree = Child (Child (RootOfTree(1), 2), 1);
   AddTree (LitNode, TempTree, 2);

   TempTree = Child(Child (Child (RootOfTree(1), 2), 1),2);
   AddTree(IdentifierNode, TempTree, 1);

   TempTree = Child(Child (Child (RootOfTree(1), 2), 1),2);
   AddTree(IdentifierNode, TempTree, 1);

   TempTree = Child(Child(Child (Child (RootOfTree(1), 2), 1),2),1);
   AddTree (FalseNode, TempTree, 1);

   TempTree = Child(Child(Child (Child (RootOfTree(1), 2), 1),2),2);
   AddTree (TrueNode, TempTree, 1); 
 
   TempTree = Child (Child (RootOfTree(1), 2), 2);
   AddTree (IdentifierNode, TempTree, 1);

   TempTree = Child(Child (Child (RootOfTree(1), 2), 2),1);
   AddTree (IntegerTNode, TempTree, 1);

   TempTree = Child (Child (RootOfTree(1), 2), 3);
   AddTree (IdentifierNode, TempTree, 1);

   TempTree = Child(Child (Child (RootOfTree(1), 2), 3),1);
   AddTree (CharacterTNode, TempTree, 1);   

   TempTree = Child (RootOfTree(1), 2);

   TypeBoolean = Child(TempTree,1);
   TypeInteger = Child(TempTree,2);
   TypeChar = Child(TempTree,3);
         

}



void ErrorHeader (TreeNode T)
{ 
   printf ("<<< CONSTRAINER ERROR >>> AT ");
   Write_String (stdout,SourceLocation(T));
   printf (" : ");
   printf ("\n");
}


int NKids (TreeNode T)
{
   return (Rank(T));
}



UserType Expression (TreeNode T)
{
   UserType Type1, Type2;
   TreeNode Declaration, Temp1, Temp2,Pchild;
   int NodeCount,Kid,Kid1;
   int Pcount = 0;
   int i = 2;

   if (TraceSpecified)
   {
      fprintf (TraceFile, "<<< CONSTRAINER >>> : Expn Processor Node ");
      Write_String (TraceFile, NodeName(T));
      fprintf (TraceFile, "\n");
   }
     
   switch (NodeName(T))
   {
      case LENode :    
      case GTENode :
      case NEQNode :
      case LTNode :
      case GTNode :
      case EQNode :
         Type1 = Expression (Child(T,1));
         Type2 = Expression (Child(T,2));

         if (Type1 != Type2)
         {
            ErrorHeader(Child(T,1));
            printf ("ARGUMENTS AROUND CONDITIONAL OPERATOR MUST BE OF SAME TYPE\n");
            printf ("\n");
         }
         return (TypeBoolean);

      case AndNode :    
      case OrNode:
         Type1 = Expression (Child(T,1));
         Type2 = Expression (Child(T,2));

         if (Type1 != Type2)
         {
            ErrorHeader(Child(T,1));
            printf ("ARGUMENTS OF BOOLEAN OPERATORS MUST BE TYPE INTEGER OR BOOLEAN\n");
            printf ("\n");
         }
         return (TypeBoolean);

      case ExpNode :
      case ModNode :    
         Type1 = Expression (Child(T,1));
         Type2 = Expression (Child(T,2));

         if (Type1 != Type2 || Type1 != TypeInteger)
         {
            ErrorHeader(Child(T,1));
            printf ("ARGUMENTS OF 'EXP','MOD' MUST BE TYPE INTEGER\n");
            printf ("\n");
         }
         return (TypeInteger);
    
      case NotNode :    
         Type1 = Expression (Child(T,1));

         if (Type1 == TypeChar)
         {
            ErrorHeader(Child(T,1));
            printf ("ARGUMENTS OF 'NOT' MUST NOT BE OF TYPE CHAR\n");
            printf ("\n");
         }
         return (TypeBoolean);


      case PlusNode :
      case MinusNode : 
         Type1 = Expression (Child(T,1));

         if (Rank(T) == 2)
            Type2 = Expression (Child(T,2));
         else  
            Type2 = TypeInteger;

         if (Type1 != TypeInteger || Type2 != TypeInteger)
         {
            ErrorHeader(Child(T,1));
            printf ("ARGUMENTS OF 'BPLUS', 'BMINUS' MUST BE TYPE INTEGER\n");
            printf ("\n");
         }
         return (TypeInteger);

      case MultNode :
      case DivNode :    
         Type1 = Expression (Child(T,1));
         Type2 = Expression (Child(T,2));

         if (Type1 != TypeInteger ||  Type2 != TypeInteger)
         {
            ErrorHeader(Child(T,1));
            printf ("ARGUMENTS OF 'DIVIDE','MULTIPLY' MUST BE TYPE INTEGER\n");
            printf ("\n");
         }
         return (TypeInteger);


     case SuccNode:
     case PredNode:
     	 return (Expression(Child(T,1)));

     case OrdNode:
	  Type1 = Expression(Child(T,1));
	  return (TypeInteger);

     case ChrNode:
	  Type1 =Expression(Child(T,1));
	  if(Type1 != TypeInteger){
		ErrorHeader(T);
		printf(" only integers in CHR are allowed\n");
	  }
	  return(TypeChar);

      case TrueNode :
      case FalseNode :
      case EofNode :
         return (TypeBoolean);

      case CharacterNode :
           return (TypeChar);

      case IntegerNode : 
         return (TypeInteger);


      case IdentifierNode :
	 /*printf("here for lookup!");*/
         Declaration = Lookup (NodeName(Child(T,1)), T);
	 /*printf("Done lookup!");*/
         if (Declaration != NullDeclaration)
         {
            Decorate (T, Declaration);
            return (Decoration(Declaration));
         }
         else
            return (TypeInteger);

	case CallNode :
	    Type1 = Expression(Child(T,1));
	    if (ModeOf(Child(T,1)) != FunctionNode){
	    	ErrorHeader(T);
	   	printf("MODE OF FUNCTION VARIABLE WRONG\n");
	    }
	    Temp1 = Decoration(Child(T,1));
	    Temp2 = Child(Decoration(Child(Temp1,1)),2);
	    if (NodeName(Temp2) == ParamsNode){
	    	for (Kid = 1 ; Kid <= NKids(Temp2) ; Kid++){
	    		Pcount = Pcount + NKids(Child(Temp2,Kid)) - 1;
	    	}
	    }	
	    if (Pcount != NKids(T)-1){
	    	ErrorHeader(T);
	 	printf("PARAMETER COUNT DON'T MATCH\n");
            }
	    if (NodeName(Temp2) == ParamsNode){
	    	for (Kid = 1 ; Kid <= NKids(Temp2) ; Kid++){
			for (Kid1 = 1 ; Kid1 < NKids(Child(Temp2,Kid)) ; Kid1++){
				if (Decoration(Child(Child(Temp2,Kid),Kid1)) != Expression(Child(T,i))){
					ErrorHeader(T);
					printf("TYPE OF CHILD %d DON'T MATCH IN THE CALL\n",i);
				}
			i++;
            		}
	    	}
	    }
	return (Type1);

	case DotDotNode :
	 Type1 = Expression(Child(T,1));
	 Type2 = Expression(Child(T,2));
	 if(Type1 != Type2)
	 {
		ErrorHeader(T);
		printf("Both must be same type around ..\n");
	 }
	 if((NodeName(Child(T,1)) == IdentifierNode && ModeOf(Child(T,1)) == VarNode)|| (NodeName(Child(T,2))== IdentifierNode && ModeOf(Child(T,2)) == VarNode))
	 {
		ErrorHeader(T);
		printf("Case label cannot not be vartype around ..\n");
	 }
	return (Type1);

      default :
         ErrorHeader(T);
         printf ( "UNKNOWN NODE NAME ");
         Write_String (stdout,NodeName(T));
         printf ("\n");

   }  /* end switch */
}  /* end Expression */

String ModeOf(TreeNode T){
	TreeNode T1,T2;
	String name;

	T1 = Decoration(T);
	T2 = Child(T1,1);
	name = NodeName(Decoration(T2));
	/*printf("%d",name);
	printf("%d",TypeNode);
	printf("%d",VarNode);*/
	
	return name;
}


void ProcessNode (TreeNode T) 
{
   int Kid, N, Kid1, i = 2, Pcount = 0;
   String Name1, Name2;
   TreeNode Type1, Type2, Type3,Temp, Temp1, Temp2;

   if (TraceSpecified)
   {
      fprintf (TraceFile,
               "<<< CONSTRAINER >>> : Stmt Processor Node ");
      Write_String (TraceFile, NodeName(T));
      fprintf (TraceFile, "\n");
   }

   switch (NodeName(T))
   {
      case ProgramNode : 
	 DTEnter(SUBPROG_CTXT,T,T);
         OpenScope();
	 DTEnter(LOOP_CTXT,T,T);
	 DTEnter(FOR_CTXT,T,T);
         Name1 = NodeName(Child(Child(T,1),1));
         Name2 = NodeName(Child(Child(T,NKids(T)),1));

         if (Name1 != Name2)
         {
           ErrorHeader(T);
           printf ("PROGRAM NAMES DO NOT MATCH\n");
           printf ("\n");
         }

         for (Kid = 2; Kid <= NKids(T)-1; Kid++)
            ProcessNode (Child(T,Kid));
         CloseScope();
         break;

      case SubProgsNode :
	  for (Kid = 1;Kid <= NKids(T);Kid++)
		ProcessNode(Child(T,Kid));
	  break;

      case FunctionNode :
	  Name1 = NodeName(Child(Child(T,1),1));
          Name2 = NodeName(Child(Child(T,NKids(T)),1));

         if (Name1 != Name2)
         {
           ErrorHeader(T);
           printf ("FUNCTION NAMES DO NOT MATCH\n");
           printf ("\n");
         }
	 DTEnter(NodeName(Child(Child(T,1),1)),Child(T,1),T);
	 OpenScope();
	 DTEnter(SUBPROG_CTXT,T,T);
	 if (NodeName(Child(T,3)) == IdentifierNode)
	 	Type1 = Lookup(NodeName(Child(Child(T,3),1)),T);
	 else
	 	Type1 = Lookup(NodeName(Child(Child(T,2),1)),T);
	 Decorate(Child(T,1),Decoration(Type1));
	 Decorate(Child(Child(T,1),1),T);
	 Kid = 0;
	 if (NodeName(Child(T,2)) == ParamsNode){
	 	ProcessNode(Child(T,2));
		Kid = 4;
	 }
	 else	
		Kid = 3;
	 for ( ; Kid < NKids(T) ; Kid++)
		ProcessNode(Child(T,Kid));
	 CloseScope();	 
	break;

      case ProcedureNode :
	  Name1 = NodeName(Child(Child(T,1),1));
          Name2 = NodeName(Child(Child(T,NKids(T)),1));

         if (Name1 != Name2)
         {
           ErrorHeader(T);
           printf ("PROCEDURE NAMES DO NOT MATCH\n");
           printf ("\n");
         }
	 DTEnter(NodeName(Child(Child(T,1),1)),Child(T,1),T);
	 OpenScope();
	 DTEnter(SUBPROG_CTXT,T,T);
	 Decorate(Child(Child(T,1),1),T);
	 Kid = 0;
	 if (NodeName(Child(T,2)) == ParamsNode){
	 	ProcessNode(Child(T,2));
		Kid = 3;
	 }
	 else
		Kid = 2;
	 for ( ; Kid < NKids(T) ; Kid++)
		ProcessNode(Child(T,Kid));
	 CloseScope();	 
	break;

      case CallNode :
	    Type1 = Expression(Child(T,1));
	    if (ModeOf(Child(T,1)) != ProcedureNode){
	    	ErrorHeader(T);
	   	printf("MODE OF PROCEDURE VARIABLE WRONG\n");
	    }
	    Temp1 = Decoration(Child(T,1));
	    Temp2 = Child(Decoration(Child(Temp1,1)),2);
	    if (NodeName(Temp2) == ParamsNode){
	    	for (Kid = 1 ; Kid <= NKids(Temp2) ; Kid++){
	    		Pcount = Pcount + NKids(Child(Temp2,Kid)) - 1;
	    	}
	    }	
	    if (Pcount != NKids(T)-1){
	    	ErrorHeader(T);
	 	printf("PARAMETER COUNT DON'T MATCH IN PROCEDURE\n");
            }
	    if (NodeName(Temp2) == ParamsNode){
	  
	 	   for (Kid = 1 ; Kid <= NKids(Temp2) ; Kid++){
			for (Kid1 = 1 ; Kid1 < NKids(Child(Temp2,Kid)) ; Kid1++){
				if (Decoration(Child(Child(Temp2,Kid),Kid1)) != Expression(Child(T,i))){
					ErrorHeader(T);
					printf("TYPE OF CHILD %d DON'T MATCH IN THE CALL IN PROCEDURE\n",i);
				}
			i++;
            		}
	    	}
	    }
	break;

      case ParamsNode :
	 for (Kid = 1;Kid <= NKids(T);Kid++){
	      Decorate(Child(T,Kid), T);
	      ProcessNode(Child(T,Kid));
	 }
       break;

      case ReturnNode :
	 if (NKids(T) >= 1)
	 	Type1 =  Expression(Child(T,1));
	 Temp = Lookup(SUBPROG_CTXT,T);
	 if (NodeName(Temp) != FunctionNode){
	 	ErrorHeader(T);
		printf("RETURN WITHOUT THE FUNCTION\n");
	 }
	 if (NKids(T) >= 1){
	 	if (Decoration(Child(Temp,1)) != Type1){
	 		ErrorHeader(T);
			printf("RETURN TYPE DON'T MATCH\n");
	 	}
	}
      break;       

      case ReadNode :
	Temp = Lookup(FOR_CTXT,T);
        while(NodeName(Temp) != ProgramNode)
	{
		if(NodeName(Child(Child(Temp,1),1)) == NodeName(Child(Child(T,1),1)))
		{
			ErrorHeader(T);
			printf("CANT READ A LOOP VARIABLE\n");

			
		}
	Temp = Decoration(Temp);
	}
	for(Kid =1;Kid<= NKids(T);Kid++){
		Type1 = Expression(Child(T,Kid));
		if(ModeOf(Child(T,Kid))!= VarNode || (Type1 != TypeInteger && Type1 != TypeChar)){
			ErrorHeader(T);
			printf("TYPE or MODE of the input is incorrect!");
			printf("\n");
		}
		Decorate(Child(Child(T,Kid),1) ,Type1);
	}
	break;

      case TypesNode :  
         for (Kid = 1; Kid <= NKids(T); Kid++)
            ProcessNode (Child(T,Kid));
	        break;

	
      case TypeNode :
	       	DTEnter (NodeName(Child(Child(T,1),1)),Child(T,1),T);
         	Decorate (Child(Child(T,1),1),T);
         	if (Rank(T) == 2){
 			if (NodeName(Child(T,2)) == IdentifierNode){
			        Type1 = Expression(Child(T,2));
				Decorate(Child(T,1),Type1);
		     
         		}
			else{
				Decorate (Child(T,1),T);				
               			Type1 = Child(T,2);
               			for(Kid = 1; Kid<=NKids(Type1); Kid++){
					Decorate(Child(Type1,Kid),T);
				}
  				ProcessNode(Child(T,2));
			}
		}
		else if(Rank(T) == 1)
			Decorate(Child(T,1),T);
	
	break;


      case DclnsNode :
         for (Kid = 1; Kid <= NKids(T); Kid++)
            ProcessNode (Child(T,Kid));
         break;

      case ConstsNode :
         for (Kid = 1; Kid <= NKids(T); Kid++)
            ProcessNode (Child(T,Kid));
         break;

      case VarNode :

	 /*Name1 = NodeName (Child(T, NKids(T)));

         Type1 = Lookup (Name1,T);*/
         Type1 = Expression(Child(T,NKids(T)));
	
	 if(ModeOf(Child(T,NKids(T))) != TypeNode){
	 	ErrorHeader(T);
		printf("VAR MODE INCORRECT\n");
	 }
         for (Kid  = 1; Kid < NKids(T); Kid++)
         {
            DTEnter (NodeName(Child(Child(T,Kid),1)), Child(T,Kid), T);
            Decorate (Child(T,Kid), Type1);
	    Decorate (Child(Child(T,Kid),1),T);
	    /*printf("\n done with var = %d",NodeName(Child(Child(T,Kid),1)));*/

         }
	 break;
	
      case ConstNode :
	 Type1 = Expression(Child(T,2));
         DTEnter(NodeName(Child(Child(T,1),1)),Child(T,1),T);
	 if(NodeName(Child(T,2))== IdentifierNode){
		Name1 = ModeOf(Child(T,2));
		/*printf("Name1 = %d",Name1);
		printf("LitNode = %d",LitNode);*/
		if(Name1 != ConstNode && Name1 != LitNode){
			ErrorHeader(T);
			printf("CONST MODE INCORRECT\n");
		}
	}
	 Decorate(Child(T,1),Type1);
	 Decorate(Child(Child(T,1),1),T);
	
	 break;

      case LitNode :
	 for (Kid = 1 ; Kid <= NKids(T) ; Kid++){
		DTEnter(NodeName(Child(Child(T,Kid),1)),Child(T,Kid),T);
		Decorate(Child(Child(T,Kid),1),T);
	 }
	 break; 


      case BlockNode :
         for (Kid = 1; Kid <= NKids(T); Kid++)
            ProcessNode (Child(T,Kid));
         break;


      case AssignNode :
         Type1 = Expression (Child(T,1));
         Type2 = Expression (Child(T,2));
	 Name1 = ModeOf(Child(T,1));
	if(Name1 != VarNode && Name1 != FunctionNode){
		ErrorHeader(T);
		printf("\nMODE of CHILD 1 WRONG for AssignNode\n");
	}

	if(NodeName(Child(T,2)) == IdentifierNode){
	 Name2 = ModeOf(Child(T,2));
	if(Name2 != ConstNode && Name2 != LitNode && Name2 != VarNode){
		ErrorHeader(T);
		printf("\nMODE of CHILD 2 WRONG for AssignNode\n");
	}}
	
         if (Type1 != Type2)
         {
            ErrorHeader(T);
            printf ("ASSIGNMENT TYPES DO NOT MATCH\n");
            printf ("\n");
         }
	Temp = Lookup(FOR_CTXT,T);
        while(NodeName(Temp) != ProgramNode)
	{
		if(NodeName(Child(Child(Temp,1),1)) == NodeName(Child(Child(T,1),1)))
		{
			ErrorHeader(T);
			printf("CANT USE ASSIGNMENT LOOP VARIABLE\n");

			
		}
	Temp = Decoration(Temp);
	}
	break;

      case SwapNode :
         Type1 = Expression (Child(T,1));
         Type2 = Expression (Child(T,2));
	 Name1 = ModeOf(Child(T,1));
	 Name2 = ModeOf(Child(T,2));

	if (Name1 == ConstNode || Name2 == ConstNode){
		ErrorHeader(T);
		printf("MODES OF SWAP VARIABLES CANT BE CONST\n");
	}         

         if (Type1 != Type2)
         {
            ErrorHeader(T);
            printf ("SWAP TYPES DO NOT MATCH\n");
            printf ("\n");
         }

	Temp = Lookup(FOR_CTXT,T);
        while(NodeName(Temp) != ProgramNode)
	{
		if(NodeName(Child(Child(Temp,1),1)) == NodeName(Child(Child(T,1),1)) ||
                   NodeName(Child(Child(Temp,1),1)) == NodeName(Child(Child(T,2),1) ) )
		{
			ErrorHeader(T);
			printf("CANT SWAP LOOP VARIABLE\n");

			
		}
	Temp = Decoration(Temp);
	}

	break;
	

      case OutputNode :
	 for (Kid = 1; Kid <= NKids(T); Kid++){
		if(NodeName(Child(Child(T,Kid),1)) != LineNode){
        
	     Type1 = Expression (Child(Child(T,Kid),1));

	    if (Type1 == TypeBoolean)
            {
               ErrorHeader(T);
               printf ("No. %d OUTPUT EXPRESSION MUST NOT BE BOOLEAN \n",Kid);
               printf ("\n");
            }
	 if(Rank(Type1) ==2){
	    if (NodeName(Child(Type1,2)) == LitNode)
            {
               ErrorHeader(T);
               printf ("No. %d OUTPUT EXPRESSION MUST NOT BE ENUM \n",Kid);
               printf ("\n");
            }
	 }

	
	    Decorate(Child(T,Kid),Type1);
	 }   
	}
         break;


      case IfNode :
         if (Expression (Child(T,1)) != TypeBoolean)
         {
            ErrorHeader(T);
            printf ("CONTROL EXPRESSION OF 'IF' STMT");
            printf (" IS NOT TYPE BOOLEAN\n");
            printf ("\n");
         } 

         ProcessNode (Child(T,2));
         if (Rank(T) == 3)
            ProcessNode (Child(T,3));
         break;


      case WhileNode :
         if (Expression (Child(T,1)) != TypeBoolean)
         {
            ErrorHeader(T);
            printf ("WHILE EXPRESSION NOT OF TYPE BOOLEAN\n");
            printf ("\n");
         }
         ProcessNode (Child(T,2));
         break;

      case RepeatNode :
         if (Expression (Child(T,NKids(T))) != TypeBoolean)
         {
            ErrorHeader(T);
            printf ("REPEAT EXPRESSION NOT OF TYPE BOOLEAN\n");
            printf ("\n");
         }
	 for (Kid = 1; Kid <= NKids(T)-1; Kid++)
	        ProcessNode (Child(T,Kid));
         break;

      case LoopNode :
         OpenScope();
	 DTEnter (LOOP_CTXT,T,T);	
	 for (Kid = 1; Kid <= NKids(T); Kid++)
	        ProcessNode (Child(T,Kid));
	 CloseScope();
	 if(Decoration(T) == 0){
		printf("warning:No exit\n");	
	 }
	 break;

     case ExitNode :
	 Type1 = Lookup (LOOP_CTXT,T);
	 if (NodeName(Type1) != LoopNode)
	{
		ErrorHeader(T);
		printf("Exit without loop\n");
	}
	 Decorate(T,Type1);
	 Decorate(Type1,T);
	break;

      case NullNode : 
         break;
	
      case DownToNode :
      case ToNode:
	Temp = Lookup(FOR_CTXT,T);
	Decorate(T,Temp);
	OpenScope();
	DTEnter(FOR_CTXT,T,T);
	DTEnter(LOOP_CTXT,T,T);
	Type1 = Expression(Child(T,1));
	Type2 = Expression(Child(T,2));
	Type3 = Expression(Child(T,3));
	if (Type1 != Type2 || Type1 != Type3)
	{
		ErrorHeader(T);
		printf("All Three should have same type and that of integer only\n");
	}
	ProcessNode(Child(T,4));
	while(NodeName(Temp) != ProgramNode)
	{
		if(NodeName(Child(Child(Temp,1),1)) == NodeName(Child(Child(T,1),1)))
		{
			ErrorHeader(T);
			printf("CANT USE SAME LOOP VARIABLE\n");
		}
	Temp = Decoration(Temp);
	}
	CloseScope();
	break;

	case CaseNode :
	 Type1 = Expression(Child(T,1));
	 /*if(Type1!=TypeInteger && Type1 != TypeChar)
	 {
		ErrorHeader(T);
		printf("First child of case must be type integer\n");
	 }*/
	 for (Kid = 2 ; Kid <= NKids(T) ; Kid++){
		if(NodeName(Child(T,Kid)) != OtherwiseNode){
	 	Type2 = Expression(Child(Child(T,Kid),1));
			if (Type1 != Type2){
				ErrorHeader(T);
				printf("TYPES OF EXP & LABELS DONT MATCH\n");
			}
	 	}
	}

	 for(Kid =2;Kid <= NKids(T);Kid++)
	 {
		ProcessNode(Child(T,Kid));
	 }
	 break;

	case CaseClauseNode :
	 Type1 = Expression(Child(T,1));
	 if(NodeName(Child(T,1)) == IdentifierNode){
		if(ModeOf(Child(T,1)) == VarNode){
			ErrorHeader(T);
			printf("case label must be const or lit\n");
		}
	 }
	 ProcessNode(Child(T,2));
	 break;
	
	case OtherwiseNode :
	 ProcessNode(Child(T,1));
	 break;
	
      default :
         ErrorHeader(T);
         printf ("UNKNOWN NODE NAME ");
         Write_String (stdout,NodeName(T));
         printf ("\n");

   }  /* end switch */
}  /* end ProcessNode */
