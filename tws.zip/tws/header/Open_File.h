extern FILE *Open_File(char *Name, char *Mode);
